//
//  Modelo.swift
//  practica1
//
//  Created by ISSC612 on 06/03/20.
//  Copyright © 2020 ISSC612. All rights reserved.
//

import Foundation
import UIKit

class ModeloHD {
    var nombre : String = ""
    var descripcion : String = ""
    var imagen : UIImageView? = nil
}
